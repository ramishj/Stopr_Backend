const config = {
    port: process.env.PORT || 8000,
    // Other configuration properties
  };
  
  export default config;
  